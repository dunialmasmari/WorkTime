<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact message </title>
</head>
<body>
    <h1>Contact message </h1>
    <p>Name:<?php echo e($data['name']); ?></p>
    <p>Message:<?php echo e($data['message']); ?></p>
    <p>Email:<?php echo e($data['Email']); ?></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\WorkTime\backend\resources\views/email/ContactMail.blade.php ENDPATH**/ ?>